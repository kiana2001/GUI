# Requirement
* Python 3.7
* pygame==2.1.3.dev8

# How To Start Game
$ python main.py

# How to Play
* use LEFT/RIGHT/DOWN key to control player
* use key 'Space' to jump
* use key 's' to shoot firewall or run
